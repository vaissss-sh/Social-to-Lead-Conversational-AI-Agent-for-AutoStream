"""
rag.py — RAG Pipeline using ChromaDB + sentence-transformers embeddings.
Loads the local knowledge_base.md, chunks it, embeds it, and supports
semantic retrieval via cosine similarity.
"""

from pathlib import Path
import chromadb
from chromadb.utils import embedding_functions


class RAGPipeline:
    """
    Retrieval-Augmented Generation pipeline backed by an in-memory
    ChromaDB vector store and the all-MiniLM-L6-v2 sentence-transformer.
    """

    def __init__(self, kb_path: str = "knowledge_base.md"):
        self.client = chromadb.Client()
        self.ef = embedding_functions.DefaultEmbeddingFunction()  # all-MiniLM-L6-v2
        self.collection = self._build_collection(kb_path)

    # ── Private helpers ──────────────────────────────────────────────

    def _chunk_markdown(self, text: str) -> list[str]:
        """Split markdown into meaningful semantic chunks."""
        chunks = []
        current = []

        for line in text.splitlines():
            if line.startswith("##") and current:
                chunk = "\n".join(current).strip()
                if len(chunk) > 30:
                    chunks.append(chunk)
                current = [line]
            else:
                current.append(line)

        if current:
            chunk = "\n".join(current).strip()
            if len(chunk) > 30:
                chunks.append(chunk)

        return chunks

    def _build_collection(self, kb_path: str) -> chromadb.Collection:
        collection = self.client.get_or_create_collection(
            name="autostream_kb",
            embedding_function=self.ef,
            metadata={"hnsw:space": "cosine"},
        )

        if collection.count() == 0:
            text = Path(kb_path).read_text(encoding="utf-8")
            chunks = self._chunk_markdown(text)
            collection.add(
                documents=chunks,
                ids=[f"chunk_{i}" for i in range(len(chunks))],
            )
            print(f"[RAG] Indexed {len(chunks)} chunks from '{kb_path}'")

        return collection

    # ── Public API ───────────────────────────────────────────────────

    def retrieve(self, query: str, n_results: int = 3) -> str:
        """Return the top-k most relevant KB chunks as a single string."""
        n = min(n_results, self.collection.count())
        results = self.collection.query(query_texts=[query], n_results=n)
        docs = results["documents"][0]
        return "\n\n---\n\n".join(docs)
