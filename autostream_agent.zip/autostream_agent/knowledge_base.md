# AutoStream Knowledge Base

## Pricing Plans

### Basic Plan
- Price: $29/month
- Videos: 10 videos per month
- Resolution: 720p
- Support: Standard email support

### Pro Plan
- Price: $79/month
- Videos: Unlimited videos per month
- Resolution: 4K Ultra HD
- Features: AI-powered automatic captions
- Support: 24/7 priority support

## Company Policies

### Refund Policy
No refunds are issued after 7 days of purchase. Customers may request a refund within the first 7 days of subscribing.

### Customer Support
24/7 live support is available exclusively on the Pro plan. Basic plan users receive standard email support with responses within 24 hours.

## Product Overview

AutoStream is a SaaS platform that provides automated video editing tools for content creators. It is designed for YouTubers, Instagram creators, TikTokers, and other social media professionals who need fast, professional video edits without manual effort.

Key features include:
- Automatic video trimming and transitions
- AI-generated captions (Pro only)
- Cloud-based rendering
- Direct export to all major platforms
