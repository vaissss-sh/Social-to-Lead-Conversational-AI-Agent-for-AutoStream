"""
agent.py — LangGraph-powered Conversational AI Agent for AutoStream.

Graph topology
──────────────
  START
    │
    ▼
  classify_intent          (LLM classifies: greeting | inquiry | high_intent)
    │
    ├─ greeting/inquiry ──► rag_respond ──► END
    │
    └─ high_intent ────────► collect_lead
                                │
                                ├─ incomplete ──► END  (ask for next field)
                                │
                                └─ complete ───► capture_lead ──► END
"""

import re
from typing import Annotated, Optional

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from typing_extensions import TypedDict

from rag import RAGPipeline
from tools import mock_lead_capture

# ═══════════════════════════════════════════════════════════════════════
# State
# ═══════════════════════════════════════════════════════════════════════

class AgentState(TypedDict):
    messages:       Annotated[list, add_messages]
    intent:         str            # greeting | inquiry | high_intent
    lead_name:      Optional[str]
    lead_email:     Optional[str]
    lead_platform:  Optional[str]
    lead_captured:  bool


# ═══════════════════════════════════════════════════════════════════════
# Shared resources
# ═══════════════════════════════════════════════════════════════════════

llm = ChatAnthropic(model="claude-haiku-4-5-20251001", temperature=0.2)
rag = RAGPipeline()          # initialized once; re-used across turns


# ═══════════════════════════════════════════════════════════════════════
# Node: classify_intent
# ═══════════════════════════════════════════════════════════════════════

def classify_intent(state: AgentState) -> dict:
    """
    Use a zero-shot LLM call to classify the user's latest message.
    Returns one of: greeting | inquiry | high_intent
    """
    last_msg = state["messages"][-1].content

    # If we're mid-collection, skip re-classification and stay on track.
    if any([state.get("lead_name"), state.get("lead_email"), state.get("lead_platform")]):
        return {"intent": "high_intent"}

    prompt = (
        "Classify the following user message into exactly ONE of these intents:\n\n"
        '- "greeting"    : casual hello, small talk, no product question\n'
        '- "inquiry"     : asking about product features, pricing, or policies\n'
        '- "high_intent" : ready to sign up / try / purchase; mentions their '
        "creator platform or channel\n\n"
        f'Message: "{last_msg}"\n\n'
        "Reply with ONLY one word: greeting, inquiry, or high_intent"
    )

    response = llm.invoke([HumanMessage(content=prompt)])
    raw = response.content.strip().lower()

    # Guard against unexpected outputs
    intent = raw if raw in ("greeting", "inquiry", "high_intent") else "inquiry"
    return {"intent": intent}


# ═══════════════════════════════════════════════════════════════════════
# Node: rag_respond
# ═══════════════════════════════════════════════════════════════════════

def rag_respond(state: AgentState) -> dict:
    """
    Retrieve relevant KB chunks and generate a grounded response.
    """
    last_msg = state["messages"][-1].content
    context  = rag.retrieve(last_msg)

    system = (
        "You are a friendly and knowledgeable sales assistant for AutoStream, "
        "a SaaS platform for automated video editing.\n\n"
        "Use ONLY the knowledge base below to answer questions. "
        "If the answer isn't there, say so honestly.\n\n"
        f"### Knowledge Base\n{context}"
    )

    messages = [SystemMessage(content=system)] + list(state["messages"])
    reply    = llm.invoke(messages)
    return {"messages": [AIMessage(content=reply.content)]}


# ═══════════════════════════════════════════════════════════════════════
# Node: collect_lead
# ═══════════════════════════════════════════════════════════════════════

_PLATFORMS = ["youtube", "instagram", "tiktok", "twitter", "facebook",
              "twitch", "linkedin", "snapchat", "pinterest"]


def _extract_email(text: str) -> Optional[str]:
    m = re.search(r"[\w.\-+]+@[\w.\-]+\.\w{2,}", text)
    return m.group() if m else None


def _extract_platform(text: str) -> Optional[str]:
    lower = text.lower()
    for p in _PLATFORMS:
        if p in lower:
            return p.capitalize()
    return None


def _extract_name(text: str) -> Optional[str]:
    """Ask the LLM to pull a person's name out of the message."""
    prompt = (
        f'Extract the person\'s full name from this message if present.\n'
        f'Message: "{text}"\n'
        "Reply with the name only, or the word NONE if no name is found."
    )
    resp = llm.invoke([HumanMessage(content=prompt)])
    result = resp.content.strip()
    if result.upper() == "NONE" or len(result) > 60:
        return None
    return result.title()


def collect_lead(state: AgentState) -> dict:
    """
    Extract lead fields from the latest user message, then ask for
    whatever is still missing.
    """
    last_msg = state["messages"][-1].content
    updates: dict = {}

    # ── Extract fields not yet collected ──────────────────────────────
    if not state.get("lead_email"):
        email = _extract_email(last_msg)
        if email:
            updates["lead_email"] = email

    if not state.get("lead_platform"):
        platform = _extract_platform(last_msg)
        if platform:
            updates["lead_platform"] = platform

    if not state.get("lead_name") and not _extract_email(last_msg):
        name = _extract_name(last_msg)
        if name:
            updates["lead_name"] = name

    # Merge with existing state so we can assess completeness
    merged_name     = updates.get("lead_name")     or state.get("lead_name")
    merged_email    = updates.get("lead_email")    or state.get("lead_email")
    merged_platform = updates.get("lead_platform") or state.get("lead_platform")

    # ── Ask for the next missing field ────────────────────────────────
    missing = []
    if not merged_name:
        missing.append("your full name")
    if not merged_email:
        missing.append("your email address")
    if not merged_platform:
        missing.append("your primary creator platform (e.g. YouTube, Instagram, TikTok)")

    if missing:
        collected_summary = (
            f"Name: {merged_name or 'not yet provided'}\n"
            f"Email: {merged_email or 'not yet provided'}\n"
            f"Platform: {merged_platform or 'not yet provided'}"
        )
        system = (
            "You are a helpful AutoStream sales assistant guiding a high-intent "
            "user through sign-up.\n\n"
            f"Collected so far:\n{collected_summary}\n\n"
            f"Still needed: {', '.join(missing)}\n\n"
            "Warmly ask for the FIRST missing item only. Keep it brief."
        )
        recent   = list(state["messages"])[-4:]
        reply    = llm.invoke([SystemMessage(content=system)] + recent)
        updates["messages"] = [AIMessage(content=reply.content)]

    return updates


# ═══════════════════════════════════════════════════════════════════════
# Node: capture_lead
# ═══════════════════════════════════════════════════════════════════════

def capture_lead(state: AgentState) -> dict:
    """Call the mock CRM tool and confirm to the user."""
    result = mock_lead_capture(
        name=state["lead_name"],
        email=state["lead_email"],
        platform=state["lead_platform"],
    )

    confirmation = (
        f"🎉 You're all set, {state['lead_name']}!\n\n"
        f"Here's a summary of what I've captured:\n"
        f"• **Name:** {result['name']}\n"
        f"• **Email:** {result['email']}\n"
        f"• **Platform:** {result['platform']}\n\n"
        "Our team will be in touch shortly to get your **Pro Plan** activated. "
        "Welcome to AutoStream! 🚀"
    )
    return {
        "messages":      [AIMessage(content=confirmation)],
        "lead_captured": True,
    }


# ═══════════════════════════════════════════════════════════════════════
# Routing functions
# ═══════════════════════════════════════════════════════════════════════

def route_after_classify(state: AgentState) -> str:
    if state.get("lead_captured"):
        return "rag_respond"

    # Check if all three lead fields are already in state
    if state.get("lead_name") and state.get("lead_email") and state.get("lead_platform"):
        return "capture_lead"

    # Partial collection in progress
    if any([state.get("lead_name"), state.get("lead_email"), state.get("lead_platform")]):
        return "collect_lead"

    if state["intent"] == "high_intent":
        return "collect_lead"

    return "rag_respond"


def route_after_collect(state: AgentState) -> str:
    """After collect_lead runs, check if we now have everything."""
    if state.get("lead_name") and state.get("lead_email") and state.get("lead_platform"):
        return "capture_lead"
    return END


# ═══════════════════════════════════════════════════════════════════════
# Graph assembly
# ═══════════════════════════════════════════════════════════════════════

def build_graph():
    g = StateGraph(AgentState)

    g.add_node("classify_intent", classify_intent)
    g.add_node("rag_respond",     rag_respond)
    g.add_node("collect_lead",    collect_lead)
    g.add_node("capture_lead",    capture_lead)

    g.set_entry_point("classify_intent")

    g.add_conditional_edges(
        "classify_intent",
        route_after_classify,
        {
            "rag_respond":  "rag_respond",
            "collect_lead": "collect_lead",
            "capture_lead": "capture_lead",
        },
    )

    g.add_conditional_edges(
        "collect_lead",
        route_after_collect,
        {
            "capture_lead": "capture_lead",
            END: END,
        },
    )

    g.add_edge("rag_respond",  END)
    g.add_edge("capture_lead", END)

    return g.compile()
