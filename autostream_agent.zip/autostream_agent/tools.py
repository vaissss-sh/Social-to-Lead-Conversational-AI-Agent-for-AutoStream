"""
tools.py — Tool definitions for the AutoStream agent.
"""

import datetime


def mock_lead_capture(name: str, email: str, platform: str) -> dict:
    """
    Simulates capturing a qualified lead in a CRM system.

    Args:
        name:     Full name of the prospect
        email:    Email address
        platform: Primary creator platform (YouTube, Instagram, etc.)

    Returns:
        A dict confirming the captured lead details.
    """
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # ── Mock CRM write ────────────────────────────────────────────────
    print("\n" + "=" * 55)
    print("  ✅  LEAD CAPTURED SUCCESSFULLY")
    print("=" * 55)
    print(f"  Name      : {name}")
    print(f"  Email     : {email}")
    print(f"  Platform  : {platform}")
    print(f"  Timestamp : {timestamp}")
    print("=" * 55 + "\n")

    return {
        "status": "success",
        "name": name,
        "email": email,
        "platform": platform,
        "captured_at": timestamp,
    }
