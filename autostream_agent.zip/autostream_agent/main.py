"""
main.py — CLI entry point for the AutoStream conversational agent.

Usage:
    python main.py

Set your API key first:
    export ANTHROPIC_API_KEY="sk-ant-..."
"""

import os
import sys

from langchain_core.messages import AIMessage, HumanMessage

from agent import build_graph

WELCOME = """
╔══════════════════════════════════════════════════╗
║        AutoStream AI Sales Assistant             ║
║  Powered by LangGraph + Claude + ChromaDB RAG   ║
╚══════════════════════════════════════════════════╝
Type 'quit' or 'exit' to end the session.
"""


def run():
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("❌  ANTHROPIC_API_KEY is not set. Export it and try again.")
        sys.exit(1)

    graph = build_graph()

    # Initial state — all lead fields are None / False
    state: dict = {
        "messages":      [],
        "intent":        "greeting",
        "lead_name":     None,
        "lead_email":    None,
        "lead_platform": None,
        "lead_captured": False,
    }

    print(WELCOME)

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in {"quit", "exit", "q"}:
            print("Thanks for chatting! Goodbye 👋")
            break

        # Append user message and run one graph turn
        state["messages"].append(HumanMessage(content=user_input))
        state = graph.invoke(state)

        # Print the latest AI response
        ai_msgs = [m for m in state["messages"] if isinstance(m, AIMessage)]
        if ai_msgs:
            print(f"\nAgent: {ai_msgs[-1].content}\n")

        if state.get("lead_captured"):
            print("✅  Lead capture complete. Workflow finished.\n")
            break


if __name__ == "__main__":
    run()
